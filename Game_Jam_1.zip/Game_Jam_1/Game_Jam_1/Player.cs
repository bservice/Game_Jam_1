﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game_Jam_1
{
    class Player
    {
        private int health;

        public Player()
        {
            health = 3;
        }

        public void Print()
        {
            Console.WriteLine(health);
        }

        public void Hit()
        {
            health--;
        }
    }
}
